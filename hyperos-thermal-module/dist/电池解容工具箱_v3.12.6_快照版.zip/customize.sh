#!/system/bin/sh
# 电池解容工具箱 (battery_tune) 安装脚本（版本号运行时读取 module.prop）
# 适用: 小米15系 + 17系 + K90系 + MIX Flip2 + Turbo 4 Pro + miro/songyuan/warsaw/pudding — xuanyuan(15 Ultra) / dada(15) / haotian(15 Pro) / nezha(17 Ultra) / myron(K90 Pro Max) / annibale(K90) / bixi(MIX Flip2) / onyx(Turbo 4 Pro) / popsicle(17 Pro Max) / miro(K80 Pro) / songyuan(K100 Pro Max) / warsaw(K90 Ultra) / pudding(17)
# KernelSU · Magisk · APatch
# ============================================
ui_print " "
_VER=$(grep '^version=' "$MODPATH/module.prop" 2>/dev/null | head -n1 | cut -d= -f2)
[ -n "$_VER" ] || _VER="v3.12.6"
ui_print "  电池解容工具箱 $_VER  ·  解容 / 限流 / 云控"
ui_print "  支持: 15 /15Pro /15Ultra /17 /17Ultra /17ProMax /K90PM /K90 /Flip2 /T4Pro /K80Pro /K100PM /K90U"

# ===== v3.0.0 安装输出瘦身 =====
# 【为什么】旧版安装界面一次刷 35~40 行，用户根本读不完，真正重要的
#   （设备识别 / DTBO 怎么办 / 装完要重启 / 开关默认值）被淹没。
#   现在：过程细节用 _vlog 只写日志；界面只留关键节点 + 精简收尾。
#   完整说明外链到包外的 README，作者单独上传给用户看。
_vlog(){ echo "$(date '+%F %T') [install] $*" >> /data/local/tmp/xt_toolbox.log 2>/dev/null; }
ip(){ ui_print "$1"; _vlog "$1"; }

# ---- 安全追加键值（自动补末行换行，防止粘连）----
_add_kv() {
  _f="$MODPATH/config/settings.conf"
  if [ -s "$_f" ] && [ "$(tail -c1 "$_f" | wc -l)" = "0" ]; then echo "" >> "$_f"; fi
  echo "$1" >> "$_f"
}

# ---- 设备识别: xuanyuan / dada / haotian / nezha / myron / annibale / bixi / onyx / popsicle ----
DEV=$(getprop ro.product.device)
VD=$(getprop ro.product.vendor.device)
NM=$(getprop ro.product.name)
MODEL=$(getprop ro.product.model)
CODE=""
for _c in xuanyuan dada haotian nezha myron annibale bixi onyx popsicle miro songyuan warsaw pudding pandora byron; do
  if [ "$DEV" = "$_c" ] || [ "$VD" = "$_c" ] || [ "$NM" = "$_c" ]; then CODE=$_c; break; fi
done
if [ -z "$CODE" ]; then
  ui_print " "
  ui_print "!! 安装已终止: 设备不匹配!"
  ui_print "!! 本模块支持: 小米15 Ultra(xuanyuan) / 小米15(dada) / 小米15 Pro(haotian) / 小米17 Ultra(nezha) / K90 Pro Max(myron) / K90(annibale) / MIX Flip2(bixi) / Turbo 4 Pro(onyx) / 17 Pro Max(popsicle) / K80 Pro(miro) / K100 Pro Max(songyuan) / K90 Ultra(warsaw) /小米17(pudding) / 小米17 Pro(pandora) / 小米17 Max(byron)"
  ui_print "!! 当前设备: $MODEL (dev=$DEV / name=$NM)"
  abort "设备不支持"
fi
case "$CODE" in
  xuanyuan) DNAME="小米15 Ultra" ;;
  dada)     DNAME="小米15" ;;
  haotian)  DNAME="小米15 Pro" ;;
  nezha)    DNAME="小米17 Ultra" ;;
  myron)    DNAME="Redmi K90 Pro Max" ;;
  annibale) DNAME="Redmi K90" ;;
  bixi) DNAME="小米 MIX Flip2" ;;
  onyx) DNAME="Redmi Turbo 4 Pro" ;;
  popsicle) DNAME="小米17 Pro Max" ;;
  miro)     DNAME="Redmi K80 Pro" ;;
  songyuan) DNAME="Redmi K100 Pro Max" ;;
  warsaw)   DNAME="Redmi K90 Ultra" ;;
  pudding)  DNAME="小米17" ;;
  pandora)  DNAME="小米17 Pro" ;;
byron)    DNAME="小米17 Max" ;;
esac
ui_print "- 设备识别: $MODEL → $CODE ($DNAME)"

# ---- BAA 载荷部署（按机型自动选择）----
POOL=$MODPATH/baa/pool/$CODE
if [ ! -d "$POOL" ]; then
  abort "安装包缺少该机型载荷目录: baa/pool/$CODE"
fi
mkdir -p $MODPATH/baa/modes
for f in normal.json normal_nocloud.json normal_plain.json normal_nocloud_plain.json; do
  cp -f "$POOL/$f" $MODPATH/baa/modes/
done
rm -f $MODPATH/baa/modes/ffc.json $MODPATH/baa/modes/ffc_nocloud.json \
      $MODPATH/baa/modes/ffc_plain.json $MODPATH/baa/modes/ffc_nocloud_plain.json
cp -f $POOL/stock_BAA_config_$CODE.json $MODPATH/baa/stock_BAA_config_$CODE.json
cp -f $POOL/payload_BAA_config_$CODE.json $MODPATH/baa/payload_BAA_config_$CODE.json
for _oc in xuanyuan dada haotian nezha myron annibale bixi onyx popsicle miro songyuan warsaw pudding byron; do
  [ "$_oc" = "$CODE" ] && continue
  rm -f $MODPATH/baa/payload_BAA_config_$_oc.json $MODPATH/baa/stock_BAA_config_$_oc.json
done
N_MODE=$(ls $MODPATH/baa/modes/*.json 2>/dev/null | wc -l)
_vlog "BAA载荷部署: $CODE (modes ${N_MODE}件 + payload/stock)"

# ===== v2.9.4 【体积优化】部署完立刻删掉 baa/pool（-4.9 MB / 模块占用的 59%）=====
# 【依据 · 设备端实证】
#   · 运行期 0 引用：scripts/ 全部脚本与 webroot/index.html 对 `baa/pool` 命中数 = 0
#   · 运行期只读 baa/modes/（由 common.sh 的 baa_refresh_src 按 cloud_guard/baa_fmt 二选一）
#   · pool 的唯一用途就是上面这几行"安装期拷贝到 modes"——拷完即完成使命
#   · 实测占用：pool 4909 KB / 模块总计 8320 KB = 59.3%
# 【收益】模块落盘 8.32 MB → 约 3.4 MB；且升级时不再重复搬运 4.9 MB
# 【风险】无（同一安装流程内，pool 的所有消费点都在本行之前）
if [ -d $MODPATH/baa/pool ]; then
  rm -rf $MODPATH/baa/pool 2>/dev/null
  if [ -d $MODPATH/baa/pool ]; then
    ui_print "- 提示: baa/pool 清理未完全（不影响功能，仅占空间）"
  else
    _vlog "已清理安装期临时载荷 baa/pool（省约 4.9 MB）"
  fi
fi
# 旧版本装过的 pool 残留在【上一版模块目录】里，框架替换时会一并消失；
# 但若用户是从旧版升级且框架保留了旧文件（叠加式），下面这行兜底清一次。
[ -d /data/adb/modules/battery_tune/baa/pool ] && \
  rm -rf /data/adb/modules/battery_tune/baa/pool 2>/dev/null

# ---- 从旧版模块迁移（xuanyuan_battery_tune -> battery_tune）----
# v2.7.5：键表抽成变量与「同款升级」共用 —— 原先这里是 v1.5 时代的 7 键，
#   导致从 xuanyuan_battery_tune 升级的用户【温控守护/标定值全部丢失】，
#   而新默认已变成 thermal_guard=0 → 该人群的温控被静默关闭（升级回归）。
# v2.9.3：补 cg_min_write_gap / thermal_ceil —— 这两个键是文档明确引导用户现场标定的
#   （settings.conf 里有大段说明"调小更激进 / 调大更保守"），
#   漏迁移 → 用户标定值被静默复位成默认，且完全看不出来。
# ★v2.10.7：曾把 freepps 从迁移列表移除，让升级强制采用默认 1（+22% 功率）。
# ★v3.0.0：**改回来** —— 这是公用发行版，作者决定：
#   · 新装用户默认 freepps=0（保守，需要时自己在 WebUI 开）
#   · 升级用户 freepps 重新纳入迁移 → **完全沿用你原来的设置**，不被本版默认值覆盖
#   理由：强制打开会改变老用户既有充电行为（官方头用户可能反而变慢），
#         而它是可感知的行为变化，不该在升级时静默发生。
_MIG_KEYS="unlock fv_guard pss_disable pss_low_soc pss_low_hyst cycle_fake backup_dir power_limit cloud_guard baa_fmt fast_w mid_w slow_w power_mech max_ma mid_ctrl slow_ctrl thermal_guard thermal_limit thermal_hyst thermal_action freepps closed_loop cg_min_write_gap thermal_ceil"
# 【v2.9.10 为什么把 pss_disable 从迁移白名单里移除】
#   旧默认 pss_disable=1 会禁用 com.miui.powercenter.provider.PowerSaveService，
#   真机实测（xuanyuan 2026-10-17）该禁用会导致
#   com.miui.securitycenter.remote 不启动 → BatteryHealthUtils 不运行 →
#   **设置里的「电池健康度」不显示**（用户可见的功能缺失）。
#   移除后：老用户升级时该键不再被旧值覆盖 → 采用新默认 0 → 自动恢复健康度。
#   下面的专门迁移块还会主动 `pm enable` 一次，让升级【无需重启】就恢复显示。

# ===== v2.9.4 【升级必须先停旧守护 —— 真正提到最前】=====
# 【为什么又改一次】v2.9.3 确实加了 kill，但它排在 `[ -d "$PREV" ]` 之内、
#   且位于【旧模块迁移 与 BAA 部署】之后 → 注释自称"动文件之前"，实际在那之前
#   早就动过文件了，竞态窗口依然存在。
# 【后果（= 用户反馈的"新版覆盖旧版有概率出现代码异常"的真身）】
#   ① 旧 cloud_guard 继续把系统云端配置 `mv` 进 state/cloud_quarantine/，
#      而该目录马上要被框架替换 → **用户的系统原件永久丢失**；
#   ② 旧 inotifyd 回调 + fv_guard 的轮询子进程仍在把 smart_fv 强制写 0；
#   ③ 旧 freepps(Rust) 仍占着 pd_verifed 节点，与新版本抢同一批内核旋钮；
#   ④ 旧 charge_guard 与新装脚本并发写同一批充电节点。
# 【修法】定义成函数后【在任何文件动作之前】调用。
#   清单与 uninstall.sh 对齐，并补上 v2.9.3 漏掉的三类：
#     · inotifyd（fv_guard 用它监听 battery 节点）
#     · freepps 的两种进程名形态（bin/freepps 与 legacy FreePPS/bin/FreePPS）
#     · fv_guard / cycle_guard / thermal_guard 的轮询子 shell —— 其 cmdline 是裸
#       `sh`、**不含 battery_tune 路径**，pgrep -f 永远命中不了 → 只能按 pidfile 补杀
xbt_kill_all_old() {
  command -v pgrep >/dev/null 2>&1 || return 0
  for _pat in 'battery_tune/scripts/charge_guard\.sh' \
              'battery_tune/scripts/thermal_guard\.sh' \
              'battery_tune/scripts/cycle_guard\.sh' \
              'battery_tune/scripts/cloud_guard\.sh' \
              'battery_tune/scripts/diag_log\.sh' \
              'battery_tune/scripts/fv_guard\.sh' \
              'battery_tune/scripts/fv_handler\.sh' \
              'battery_tune/scripts/thermal_ctl\.sh' \
              'battery_tune/bin/freepps' \
              'battery_tune/bin/inotifyd' \
              'FreePPS/bin/FreePPS' \
              'xuanyuan_battery_tune/scripts/' ; do
    for _p in $(pgrep -f "$_pat" 2>/dev/null); do kill -9 "$_p" 2>/dev/null; done
  done
  # 游离 inotifyd（cmdline 只含 fv_handler.sh 路径片段）
  for _p in $(pgrep -f 'fv_handler\.sh' 2>/dev/null); do kill -9 "$_p" 2>/dev/null; done
  # 轮询子 shell：cmdline 不含模块路径 → 按 pidfile 补杀（唯一能命中的方式）
  for _pf in /data/local/tmp/xt_fv_guard.pid \
             /data/local/tmp/xt_cycle_guard.pid \
             /data/local/tmp/xt_thermal_guard.pid \
             /data/local/tmp/xt_charge_guard.pid \
             /data/local/tmp/xt_cloud_guard.pid \
             /data/local/tmp/xt_diag_log.pid; do
    [ -f "$_pf" ] || continue
    _op=$(cat "$_pf" 2>/dev/null)
    case "$_op" in
      ''|*[!0-9]*) : ;;
      *) kill -9 "$_op" 2>/dev/null ;;
    esac
  done
  return 0
}
xbt_kill_all_old
_vlog "已停止旧版守护进程（升级前）"

OLD_DIR=/data/adb/modules/xuanyuan_battery_tune
if [ -d "$OLD_DIR" ]; then
  OLD_CONF=$OLD_DIR/config/settings.conf
  if [ -f "$OLD_CONF" ]; then
    for _k in $_MIG_KEYS; do
      # v2.7.5：空值也要迁移（`cycle_fake=` 表示"不伪装"，是合法值）
      if ! grep -qE "^${_k}=" "$OLD_CONF" 2>/dev/null; then
        continue
      fi
      _v=$(grep -E "^${_k}=" "$OLD_CONF" 2>/dev/null | tail -n 1 | cut -d= -f2-)
      if grep -qE "^${_k}=" $MODPATH/config/settings.conf; then
        # v3.0.0：分隔符 | → @（同类隐患加固，见 v2.10.8 的 snapshot sed bug）
      sed -i "s@^${_k}=.*@${_k}=${_v}@" $MODPATH/config/settings.conf
      else
        _add_kv "${_k}=${_v}"
      fi
    done
  fi
  if [ -d "$OLD_DIR/state" ]; then
    mkdir -p $MODPATH/state
    cp -af "$OLD_DIR/state/." $MODPATH/state/ 2>/dev/null
  fi
  if [ ! -f "$OLD_DIR/disable" ]; then
    touch "$OLD_DIR/disable" 2>/dev/null
    { echo '#!/system/bin/sh'; echo '# (superseded by battery_tune) no-op'; echo 'exit 0'; } > "$OLD_DIR/uninstall.sh" 2>/dev/null
    ui_print " "
    ui_print "!! 检测到旧版模块 (xuanyuan_battery_tune)"
    ui_print "   -> 设置与状态已迁移；旧模块已标记禁用"
    ui_print "   -> 重启后旧模块不再加载（可在 KernelSU 中手动删除）"
    ui_print " "
  else
    ui_print "- 检测到旧模块 (xuanyuan_battery_tune)：已处于禁用状态"
  fi
fi

# ---- 同款模块升级：保留用户设置与累计状态（v2.5.0）----
# v2.7.5 修正：原来用 `[ -n "$_v" ] || continue` 过滤空值 ——
#   这会让"用户明确设为空"的键无法迁移。实际踩到的例子：
#     `cycle_fake=`（不伪装）是空值 → 迁移时被跳过 → 老模块里的 cycle_fake=50 被保留
#     → 用户在安装界面明明选了"不伪装"，升级后却仍在伪装（假状态）。
#   `backup_dir` / `dev_code` 等同理（空值是合法的"不设置"）。
#   现改为：**只要旧配置里存在该键就迁移（含空值）**，只有键不存在才跳过。
PREV=/data/adb/modules/battery_tune
if [ -d "$PREV" ]; then
  # ===== v2.9.3 【升级必须先停旧守护】=====
  # 【问题】customize.sh 全文没有任何 kill/pgrep —— 升级时旧版的 charge_guard /
  #   thermal_guard / cloud_guard / freepps 全部【继续运行】。后果：
  #     ① 旧 cloud_guard 会在升级期间继续把系统云端配置 mv 进
  #        state/cloud_quarantine/ —— 而那个目录马上要被替换掉 → 原件永久丢失
  #        （这正是上面"迁移隔离区"要防的场景，但进程不停就防不住）
  #     ② 旧 charge_guard 继续写充电节点，与新装的脚本并发操作同一批节点
  #     ③ 旧进程的 pid/状态文件与新版本对不上
  # ===== v2.9.4：旧守护已在【本文件最开头】统一停掉（xbt_kill_all_old）=====
  #   v2.9.3 的 kill 块原本就在这里 —— 位置太晚：此时旧模块迁移与 BAA 部署
  #   都已完成，竞态窗口仍在（旧 cloud_guard 能把系统原件搬走、旧 fv_guard
  #   子进程能继续写 smart_fv）。现上移到 _MIG_KEYS 之后、任何文件动作之前，
  #   并补齐了 inotifyd / freepps / pidfile 三类漏网。
  if [ -f "$PREV/config/settings.conf" ]; then
    for _k in $_MIG_KEYS; do
      if ! grep -qE "^${_k}=" "$PREV/config/settings.conf" 2>/dev/null; then
        continue   # 旧配置里没有这个键 → 用新默认值
      fi
      _v=$(grep -E "^${_k}=" "$PREV/config/settings.conf" 2>/dev/null | tail -n 1 | cut -d= -f2-)
      if grep -qE "^${_k}=" $MODPATH/config/settings.conf; then
        # v3.0.0：分隔符 | → @（同类隐患加固，见 v2.10.8 的 snapshot sed bug）
      sed -i "s@^${_k}=.*@${_k}=${_v}@" $MODPATH/config/settings.conf
      else
        _add_kv "${_k}=${_v}"
      fi
    done
    _vlog "已保留升级前的用户设置"
  fi

  # ===== v2.9.10【升级迁移：只纠正 pss_initial 的污染值，不改当前 PSS 状态】=====
  # 【背景】PSS(PowerSaveService) 是解容第 3 步（低电量锁容防护），默认就要禁用，
  #   所以**不动 pss_disable、也不动组件当前状态**（那是用户/解容总开关的决定）。
  # 【但旧版有一个真 bug 必须修】旧 uninstall.sh 只看 state/pss_initial：
  #   若它是 "disabled"（很可能是「旧版先禁用、之后才拍快照」的污染值），
  #   卸载时就判定"安装前就是禁用"→ **永久不还原 PSS** → 卸载后电池健康度永远不显示。
  #   这正是社区需要第三方脚本（BatteryScope）来修的原因。
  # 【修法】把污染快照纠正为 "enabled"（原值留 .polluted 作证据），使卸载时能正确还原；
  #   PSS 当前实际状态与 pss_disable 配置一律不动。
  # 【另】若用户想「健康度可见 + 低电量仍防锁容」，把 pss_low_soc 设为 20~30 即可
  #   （动态模式：只有 SOC ≤ 该值时才禁用 PSS）。
  if [ "$(cat "$PREV/state/pss_initial" 2>/dev/null)" = "disabled" ]; then
    mkdir -p $MODPATH/state 2>/dev/null
    cp -f "$PREV/state/pss_initial" $MODPATH/state/pss_initial.polluted 2>/dev/null
    echo "enabled" > $MODPATH/state/pss_initial
    _vlog "已修正 PSS 快照污染"
  fi
  if [ -d "$PREV/state" ]; then
    mkdir -p $MODPATH/state
    # v2.6.23：加入 thermal_prev —— 温控保护触发时"保护前档位"只存在于此快照，
    #   而保护档已写进 settings.conf；升级时不迁移则重启后永久停在保护档无法恢复
    # v2.7.5：补 current_limit_node / current_limit_default —— 这是 <v2.6.23 的旧格式
    #   电流快照；common.sh 的 snapshot_current_limit() 依赖它们把"原始电流"并入新格式。
    #   不迁移则：从旧版升级后卸载时 restore_current_limit 找不到原始值 → 电流节点
    #   停在模块写入值，只能靠"温控闸归 0"兜底。
    #   diag/ 目录不迁移（只是诊断历史，价值低、体积可能大）。
    # v2.9.10：**pss_initial 故意不在本列表** —— 它由上面的 PSS 迁移块显式处理。
    #   若在此迁移，会把旧版的污染值("disabled")覆盖回去，导致卸载时又不还原。
    for _sf in direct_current_defaults direct_control_defaults last_real_cycle.txt baa_fmt cloud_guard.state extra_dirs.txt fv_default thermal_prev current_limit_node current_limit_default thermal_slow_w_prev inf_node_capped; do
      [ -f "$PREV/state/$_sf" ] && cp -f "$PREV/state/$_sf" "$MODPATH/state/$_sf" 2>/dev/null
    done
    # ===== v2.9.3 【🔴 数据丢失修复】迁移云控隔离区 =====
    # 【问题】cloud_guard.sh 用 `mv` 把系统云端配置【原件】搬进 state/cloud_quarantine/，
    #   而升级时框架会整体替换模块目录、上面这个白名单又不含该目录
    #   → 用户的系统云端配置原件【永久丢失】，uninstall.sh 的
    #     "云控隔离文件（已原样归还）"承诺从这一刻起就失效了。
    #   更糟：旧 cloud_guard 进程在升级期间仍可能继续往那个目录搬文件，放大丢失面。
    # 【修法】整目录递归迁移（-a 保留属性与 _sources.log 的来源映射）。
    if [ -d "$PREV/state/cloud_quarantine" ]; then
      mkdir -p "$MODPATH/state/cloud_quarantine"
      cp -af "$PREV/state/cloud_quarantine/." "$MODPATH/state/cloud_quarantine/" 2>/dev/null
      _cq_n=$(ls -1 "$MODPATH/state/cloud_quarantine" 2>/dev/null | wc -l)
      _vlog "已迁移云控隔离区（$_cq_n 个文件）"
    fi
    _vlog "已保留升级前的运行状态"
  fi
fi

# ---- 写入机型代号 ----
if grep -q '^dev_code=' $MODPATH/config/settings.conf; then
  sed -i "s/^dev_code=.*/dev_code=$CODE/" $MODPATH/config/settings.conf
else
  _add_kv "dev_code=$CODE"
fi
_vlog "机型代号写入: dev_code=$CODE"

_PW=90; case "$CODE" in myron|annibale|popsicle) _PW=100 ;; miro) _PW=120 ;; songyuan) _PW=100 ;; warsaw) _PW=100 ;; pudding) _PW=100 ;; byron) _PW=100 ;; onyx) _PW=90 ;; bixi) _PW=67 ;; esac
# ---- 动态改写 module.prop 简介：把「支持 小米15/15Pro/15Ultra」改成当前机型(代号) ----
if [ -f "$MODPATH/module.prop" ]; then
  sed -i "s@^description=.*@description=功率:${_PW}W MAX ｜ 电池解容:开 ｜ 云控屏蔽:开 ｜ $DNAME ($CODE)@" "$MODPATH/module.prop"
  _vlog "模块简介已更新: $DNAME ($CODE)"
fi

# ---- BAA 环境探测（展示用；挂载格式运行时自适应）----
BAA_T=/odm/etc/charger/BAA_config_$CODE.json
FMT=unknown
if [ -r "$BAA_T" ]; then
  _btsz=$(stat -c %s "$BAA_T" 2>/dev/null); case "$_btsz" in ''|*[!0-9]*) _btsz=0 ;; esac
  if [ "$_btsz" -le 8 ]; then FMT=empty
  elif head -c 8 "$BAA_T" 2>/dev/null | grep -q 'BAA_ENC:'; then FMT=enc
  elif head -c 64 "$BAA_T" 2>/dev/null | grep -q '{'; then FMT=plain; fi
fi
case "$FMT" in plain) DESCR="明文配置" ;; enc) DESCR="加密配置" ;; empty) DESCR="系统BAA为空(魔改包→将跳过挂载)" ;; *) DESCR="未探测到(运行时再判)" ;; esac
# v2.7.5：不再【无条件】把 baa_fmt 重置为 auto。
#   旧写法每次安装都覆盖 —— 用户现场排障时按指导设的 enc/plain 会被静默打回 auto
#   （行为随之改变），属于升级回归。
#   现改为：仅当旧配置里【没有】该键时才写入 auto；已有则保留用户设置。
if ! grep -q '^baa_fmt=' $MODPATH/config/settings.conf 2>/dev/null; then
  _add_kv "baa_fmt=auto"
  _vlog "BAA 载荷格式: 自动探测（auto）"
else
  _bf_now=$(grep '^baa_fmt=' $MODPATH/config/settings.conf | tail -n 1 | cut -d= -f2-)
  _vlog "BAA 载荷格式: 保留升级前设置（${_bf_now:-auto}）"
fi
ui_print "- BAA: $FMT（自适应挂载）"

# ======================================================================
# DTBO 整合：安装后询问是否顺便刷入本机解容 DTBO（音量键选择）
# ======================================================================
_dd_sha() { dd if="$1" bs=1M 2>/dev/null | sha256sum | awk '{print $1}'; }

flash_local_dtbo() {
  _img=$1; _slot=$2
  _dev=/dev/block/by-name/dtbo_$_slot
  # v2.7.5：临时补齐镜像的清理 —— 原先写在函数末尾，但成功/失败两条路径都 return 了
  #   → 那行代码【不可达】，/data/local/tmp 会残留最大 25MB。改为在函数开头注册 trap。
  trap 'rm -f /data/local/tmp/dtbo_pad_install.img 2>/dev/null' EXIT INT TERM 2>/dev/null
  if [ ! -e "$_dev" ]; then ui_print "  !! 目标分区不存在: $_dev"; return 1; fi
  _fsz=$(stat -c %s "$_img" 2>/dev/null)
  _dsz=$(blockdev --getsize64 "$_dev" 2>/dev/null)
  if [ -n "$_dsz" ] && [ -n "$_fsz" ] && [ "$_fsz" -gt "$_dsz" ]; then
    ui_print "  !! 镜像大于分区，已中止"; return 1
  fi
  _bk=/sdcard/Download/dtbo_backup
  mkdir -p "$_bk" 2>/dev/null
  _bf="$_bk/dtbo_${_slot}_before_install_$(date +%Y%m%d-%H%M%S).img"
  ui_print "  -> 备份当前 dtbo_$_slot 到 $_bf"
  if ! dd if="$_dev" of="$_bf" bs=1M 2>/dev/null; then ui_print "  !! 备份失败，已中止"; return 1; fi
  sync
  ui_print "  -> 刷入解容 DTBO ..."
  # 若镜像小于分区，先补 0 补齐到分区大小再写（避免尾部残留旧数据）。
  # ===== v2.9.3 【🔴 致命修复：补齐失败曾会静默写入短镜像并报"成功"】=====
  # 【旧行为】
  #   218  if [ "$_fsz" -lt "$_dsz" ]; then
  #   220    if cp && truncate && [ stat = 大小 ]; then _src="$_pad"; fi
  #          ← 【没有 else】！truncate 失败/不存在/空间不足 → _src 仍是短镜像
  #   226  dd if="$_src" of="$_dev"        ← 照写短镜像，分区尾部留着旧 DTBO 数据
  #   229  _nsha=$(head -c "$_ssz" "$_dev" | sha256sum)   ← 只比对"短镜像长度内"
  #   232  ✔ 刷入成功且校验一致            ← ★ 假成功
  #   而 scripts/dtbo.sh:203-205 里作者自己认定"分区尾部残留旧 dtbo 数据会导致镜像损坏"
  #   → 这条路径正好制造了那个条件，且用户看到的是"成功"。
  #   若 blockdev 缺失（_dsz 为空），大小检查与补齐【整体跳过】，同样写短镜像。
  # 【新行为】
  #   ① 补齐失败 → 【中止，不写分区】（宁可没刷，不可刷坏）
  #   ② 镜像本身带长度信息时，无法确认分区大小时也中止（不能盲写）
  #   ③ 校验改为覆盖【整个分区】（_dsz 可用时），真正发现尾部残留
  _src="$_img"
  if [ -z "$_dsz" ]; then
    # blockdev 不可用：无法判断分区大小 → 只接受"镜像 >= 分区"的情况无法判定，
    # 因此退化为：仅当镜像自带 total 且我们无法比较时，用文件大小与镜像内部 total 对齐
    if [ -n "$_fsz" ]; then
      ui_print "  !! 无法读取分区大小（blockdev 不可用），为保证安全已中止刷入"
      ui_print "     备份已保留: ${_bf:-（未生成）}"
      echo "$(date '+%F %T') install_flash_ABORT no_blockdev slot=$_slot" >> "$_bk/manifest.txt" 2>/dev/null
      return 1
    fi
  elif [ "$_fsz" -lt "$_dsz" ]; then
    _pad=/data/local/tmp/dtbo_pad_install.img
    if cp -f "$_img" "$_pad" 2>/dev/null && truncate -s "$_dsz" "$_pad" 2>/dev/null && \
       [ "$(stat -c %s "$_pad" 2>/dev/null)" = "$_dsz" ]; then
      _src="$_pad"
      ui_print "    镜像已补齐至分区大小"
    else
      # ★ 关键：补齐失败【必须中止】，不能拿短镜像去写分区
      ui_print "  !! 镜像补齐失败（truncate 不可用/空间不足），为避免写坏分区已中止"
      ui_print "     镜像 $_fsz B < 分区 $_dsz B，直接写入会留下旧数据"
      ui_print "     备份已保留: ${_bf:-（未生成）}"
      rm -f "$_pad" 2>/dev/null
      echo "$(date '+%F %T') install_flash_ABORT pad_failed fsz=$_fsz dsz=$_dsz" >> "$_bk/manifest.txt" 2>/dev/null
      return 1
    fi
  fi
  if ! dd if="$_src" of="$_dev" bs=1M 2>/dev/null; then ui_print "  !! 写入失败"; return 1; fi
  sync
  _ssz=$(stat -c %s "$_src" 2>/dev/null)
  # 校验范围：
  #   _dsz 可用 → 比对【整个分区】（这样"分区尾部残留旧数据"能被抓到）
  #              期望值 = 镜像内容 + 补齐的 0（_src 本身就是补齐后的文件，直接 hash 它）
  #   _dsz 未知 → 退回"镜像长度内"，并在提示里明确说明校验范围有限
  if [ -n "$_dsz" ]; then
    _nsha=$(head -c "$_dsz" "$_dev" 2>/dev/null | sha256sum | awk '{print $1}')
    _isha=$(sha256sum "$_src" 2>/dev/null | awk '{print $1}')
    _scope="整个分区 $_dsz B"
    # _src 必须是补齐后的（大小 == _dsz），否则上面的比较无意义
    if [ "$_ssz" != "$_dsz" ]; then
      ui_print "  !! 内部错误：待写镜像大小 $_ssz ≠ 分区 $_dsz，校验无法成立，已中止"
      echo "$(date '+%F %T') install_flash_ABORT size_mismatch ssz=$_ssz dsz=$_dsz" >> "$_bk/manifest.txt" 2>/dev/null
      return 1
    fi
  else
    _nsha=$(head -c "$_ssz" "$_dev" 2>/dev/null | sha256sum | awk '{print $1}')
    _isha=$(sha256sum "$_src" 2>/dev/null | awk '{print $1}')
    _scope="镜像长度 $_ssz B（分区大小未知，尾部未校验）"
  fi
  if [ -n "$_nsha" ] && [ "$_nsha" = "$_isha" ]; then
    ui_print "  ✔ DTBO 刷入成功且校验一致（范围: $_scope；重启后生效）"
    echo "$(date '+%F %T') install_flash_OK $_slot $_nsha <- $_img scope=$_scope" >> "$_bk/manifest.txt"
    return 0
  else
    ui_print "  ✘ 校验不一致！已保留备份: $_bf"
    ui_print "    分区=$_nsha"
    ui_print "    镜像=$_isha"
    echo "$(date '+%F %T') install_flash_VERIFY_FAIL $_slot part=$_nsha file=$_isha" >> "$_bk/manifest.txt"
    return 1
  fi
  # v2.6.22：清理补齐用的临时镜像（防 /data/local/tmp 残留 25MB）
  # v2.7.5：本行的位置已无效 —— 上面成功/失败两条路径都 return 了，这行【不可达】。
  #   清理已改到函数开头的 `trap ... EXIT` 实现（见 flash_local_dtbo 第一行）。
  #   这里保留一行兜底，覆盖"未来新增的第三条返回路径"。
  rm -f /data/local/tmp/dtbo_pad_install.img 2>/dev/null
}

key_choice() {
  # 音量键选择，返回 up/down/skip（真实计时 ≥30 秒；超时=安全默认）
  # v2.6.15b 修复：getevent 对任意输入事件都会提前返回（事件流会让"按次数计时"加速跑完），
  # 现改为按墙钟时间（date +%s）计时，保证真实等待满 30 秒。
  # v2.7 加固：安装期若 `timeout` 不存在，`getevent` 会永久阻塞 → 安装卡死（最坏结果：用户以为变砖）。
  #   ① 找不到 timeout 时用 busybox 顶上；② 再找不到就放弃按键等待直接 skip；
  #   ③ 无论哪条路径，总时长都有硬上限，保证安装一定继续。
  # v2.7.5 参数化：$1=秒数(默认30) $2=上键文案 $3=下键文案 —— 让循环伪装询问能用自己的提示
  _secs="${1:-30}"
  _lbl_up="${2:-刷入}"
  _lbl_dn="${3:-稍后}"
  case "$_secs" in ''|*[!0-9]*) _secs=30 ;; esac
  _TO=""
  if command -v timeout >/dev/null 2>&1; then
    _TO="timeout"
  elif [ -x /data/adb/ksu/bin/busybox ]; then
    _TO="/data/adb/ksu/bin/busybox timeout"
  elif [ -x /data/adb/magisk/busybox ]; then
    _TO="/data/adb/magisk/busybox timeout"
  elif command -v busybox >/dev/null 2>&1; then
    _TO="busybox timeout"
  elif command -v getevent >/dev/null 2>&1; then
    # 有 getevent 但没有任何可用的超时工具 → 绝不能直接调用（会永久阻塞）
    ui_print "  ! 环境缺少 timeout，跳过音量键选择（使用默认）"
    echo skip; return
  else
    echo skip; return
  fi
  _start=$(date +%s)
  _end=$(( _start + _secs ))
  _hard=$(( _secs + 15 ))
  _said10=0; _said5=0
  while [ "$(date +%s)" -lt "$_end" ]; do
    _ev=$($_TO 1 getevent -qlc 1 2>/dev/null)
    case "$_ev" in
      *KEY_VOLUMEUP*)   echo up;   return ;;
      *KEY_VOLUMEDOWN*) echo down; return ;;
    esac
    # 硬上限：单次 getevent 已带 1 秒超时，再多给 15 秒冗余，绝不让安装无限等待
    [ $(( $(date +%s) - _start )) -gt "$_hard" ] && break
    _rem=$(( _end - $(date +%s) ))
    if [ "$_rem" -le 10 ] && [ "$_said10" = "0" ]; then
      ui_print "  (还剩约 10 秒：音量上=$_lbl_up / 音量下=$_lbl_dn)"; _said10=1
    fi
    if [ "$_rem" -le 5 ] && [ "$_said5" = "0" ]; then
      ui_print "  (还剩约 5 秒：音量上=$_lbl_up / 音量下=$_lbl_dn)"; _said5=1
    fi
  done
  echo skip
}

# ---- v2.7.5：读取真实循环次数（用于循环伪装推荐值）----
#   ★优先级（v2.7.5 修正）：qmax_cyclecount（权威，不受伪装影响）
#     → state/last_real_cycle.txt（模块自己记录的真实值，★升级时刚被迁移进来）
#     → cyclecount / battery/cycle_count（★这两个正是【伪装写入点】，最不可信，兜底才用）
#   为什么必须这么排：伪装会同时写 cyclecount 与 battery/cycle_count，
#   若机型的 qmax_cyclecount 不存在或读失败，旧实现会把【伪装值】当真实值展示，
#   并据此算推荐值 —— 正是"伪装污染真实值"，与模块设计意图相反。
#   返回空字符串表示彻底读不到（此时不推荐，安装时跳过询问）。
read_real_cycles() {
  _v=$(cat /sys/class/xm_power/fg_master/qmax_cyclecount 2>/dev/null)
  case "$_v" in ''|*[!0-9]*)
    # 模块自己记录的真实值（common.sh 维护；升级时由 state 迁移带过来）
    _v=$(cat "$MODPATH/state/last_real_cycle.txt" 2>/dev/null) ;;
  esac
  case "$_v" in ''|*[!0-9]*)
    _v=$(cat /sys/class/xm_power/fg_master/cyclecount 2>/dev/null) ;;
  esac
  case "$_v" in ''|*[!0-9]*)
    _v=$(cat /sys/class/power_supply/battery/cycle_count 2>/dev/null) ;;
  esac
  case "$_v" in ''|*[!0-9]*) echo "" ;; *) echo "$_v" ;; esac
}

# ---- v2.7.5：按循环次数给出伪装推荐值 ----
#   ≤500 → 20 ｜ 500~600 → 50 ｜ 600~900 → 80 ｜ >900 → 200
recommend_fake() {
  _c="$1"
  case "$_c" in ''|*[!0-9]*) echo ""; return ;; esac
  if   [ "$_c" -le 500 ]; then echo 20
  elif [ "$_c" -le 600 ]; then echo 50
  elif [ "$_c" -le 900 ]; then echo 80
  else                         echo 200
  fi
}

DR=$MODPATH/dtbo
SEL_IMG="$DR/$CODE.img"
mkdir -p $MODPATH/state
if [ -f "$SEL_IMG" ]; then
  SLOT=$(getprop ro.boot.slot_suffix); SLOT=${SLOT#_}; [ -z "$SLOT" ] && SLOT=b
  DEVC=/dev/block/by-name/dtbo_$SLOT
  _cur=""
  _fsz_sel=$(stat -c %s "$SEL_IMG" 2>/dev/null)
  if [ -e "$DEVC" ] && [ -n "$_fsz_sel" ]; then
    _cur=$(head -c "$_fsz_sel" "$DEVC" 2>/dev/null | sha256sum | awk '{print $1}')
  fi
  _want=$(sha256sum "$SEL_IMG" 2>/dev/null | awk '{print $1}')
  if [ -n "$_cur" ] && [ "$_cur" = "$_want" ]; then
    ui_print "- DTBO: 当前槽 dtbo_$SLOT 已是解容版，无需刷入"
    echo "already" > $MODPATH/state/dtbo_choice
    # 仍保留匹配镜像，供 WebUI 一键刷
    mv -f "$SEL_IMG" $MODPATH/dtbo/local.img 2>/dev/null
  else
    ui_print " "
    ui_print "========================================"
    ui_print "  检测到本机解容 DTBO ($DNAME)"
    ui_print "  当前槽 dtbo_$SLOT 尚未刷入解容版"
    ui_print "========================================"
    ui_print "  音量上键 (+)  : 立即刷入解容 DTBO"
    ui_print "  音量下键 (-)  : 稍后自己刷（WebUI 一键）"
    ui_print "  (30 秒内无操作 = 稍后，可从容阅读)"
    ui_print "----------------------------------------"
    _ch=$(key_choice)
    case "$_ch" in
      up)
        ui_print "  → 已选择：立即刷入"
        if flash_local_dtbo "$SEL_IMG" "$SLOT"; then
          echo "flashed" > $MODPATH/state/dtbo_choice
          mv -f "$SEL_IMG" $MODPATH/dtbo/local.img 2>/dev/null
        else
          # v2.7.5：失败时也要保留镜像！原先失败分支没有 mv，随后又把它 rm 掉
          #   → WebUI「一键刷入本机 DTBO」找不到 local.img，用户无法重试，只能重刷整个 zip。
          echo "failed" > $MODPATH/state/dtbo_choice
          mv -f "$SEL_IMG" $MODPATH/dtbo/local.img 2>/dev/null
          ui_print "    镜像已保留，可在 WebUI「DTBO 工具」里重试"
        fi
        ;;
      *)
        ui_print "  → 已选择：稍后刷入（可在 WebUI/终端一键刷）"
        echo "later" > $MODPATH/state/dtbo_choice
        mv -f "$SEL_IMG" $MODPATH/dtbo/local.img 2>/dev/null
        ;;
    esac
  fi
  # ★v3.8.6：原先是逐个机型名列清理，v3.8.0 新增 pandora 时漏加了 → 每次安装都残留
  #   pandora.img（1.2 MB）在模块目录里（实测 /data/adb/modules/battery_tune/dtbo/pandora.img）。
  #   改成 glob 清理，以后新增机型不会再漏。
  for _img in "$DR"/*.img; do
    [ -f "$_img" ] || continue
    case "$(basename "$_img")" in
      local.img) ;;                       # 本机镜像必须保留（恢复/诊断比对用）
      *) rm -f "$_img" 2>/dev/null ;;
    esac
  done
else
  ui_print "- DTBO: 安装包不含 $CODE 镜像（跳过）"
fi

# ---- 清理历史日志副本（日志统一走「一键导出」，不再生成 /sdcard/xt_toolbox.log）----
rm -f /sdcard/xt_toolbox.log 2>/dev/null

# ---- restore 动作迁移（v2.6.22：该动作已移除，统一为 slow）----
sed -i 's/^thermal_action=restore/thermal_action=slow/' $MODPATH/config/settings.conf 2>/dev/null

# ======================================================================
# v2.7.5：循环次数伪装 —— 安装时询问（音量键，30 秒超时=不伪装）
# 背景：循环次数反映电池健康，部分用户希望显示更小的值。
#       伪装会写入 fg 的 cyclecount 节点；真实值由模块单独记录（qmax_cyclecount）。
# 推荐值按真实循环数：
#   ≤500 → 20 ｜ 500~600 → 50 ｜ 600~900 → 80 ｜ >900 → 200
# ======================================================================
_rc=$(read_real_cycles)
_rec=$(recommend_fake "$_rc")

# v2.7.5：★升级时不要重复询问 —— 否则会【覆盖用户已迁移的设置】（严重回归）
#   原先无条件问：老用户开着伪装(如 50)，升级时 30 秒内没按音量上（超时/按下键/
#   环境无 timeout 导致 skip）→ cycle_fake 被写成空 → 伪装被【静默关闭】；
#   更糟的连锁：uninstall.sh 用 `cfg_get cycle_fake ""` 判断"是否曾伪装"，
#   变成空后就再也不还原真实循环数了。
#   现改为：旧配置里已有 cycle_fake 键 → 直接沿用，不提问（同时省掉 30 秒等待）。
#   与 DTBO「已是解容版就不提问」是同一个思路。
_cf_prev=""
if [ -f "$PREV/config/settings.conf" ] && grep -qE '^cycle_fake=' "$PREV/config/settings.conf" 2>/dev/null; then
  _cf_prev=$(grep -E '^cycle_fake=' "$PREV/config/settings.conf" 2>/dev/null | tail -n 1 | cut -d= -f2-)
  ui_print " "
  ui_print "- 循环伪装: 沿用升级前设置（${_cf_prev:-不伪装}）"
  ui_print "  如需修改，安装后到 WebUI「循环计数」调整"
elif [ -z "$_rc" ]; then
  # 读不到任何循环节点 → 问了也没意义（无法给推荐值），直接跳过并提示（避免假"已开启"）
  ui_print " "
  ui_print "- 循环伪装: 未探测到循环次数节点，跳过询问（安装后可在 WebUI 设置）"
  if grep -q '^cycle_fake=' $MODPATH/config/settings.conf; then
    sed -i "s/^cycle_fake=.*/cycle_fake=/" $MODPATH/config/settings.conf
  else
    _add_kv "cycle_fake="
  fi
else
ui_print " "
ui_print "循环次数伪装（可选）  真实 $_rc 次 / 推荐伪装 ${_rec:-—} 次"
ui_print "  音量+ 开启伪装    音量- 不伪装（30 秒无操作=不伪装）"
_fch=$(key_choice 30 "开启伪装" "不伪装")
case "$_fch" in
  up)
    if [ -n "$_rec" ]; then
      # v2.7.5：伪装值不得超过真实值（真实 3 次的准新机不该被"伪装"成 20）
      if [ "$_rec" -gt "$_rc" ]; then _rec="$_rc"; fi
      if grep -q '^cycle_fake=' $MODPATH/config/settings.conf; then
        sed -i "s/^cycle_fake=.*/cycle_fake=$_rec/" $MODPATH/config/settings.conf
      else
        _add_kv "cycle_fake=$_rec"
      fi
      ui_print "  → 已开启：伪装为 $_rec 次（安装完成后生效）"
      ui_print "     真实值(${_rc:-未知})由模块单独记录，WebUI 可随时改或取消"
    else
      ui_print "  → 未写入伪装值（读不到循环次数），安装后请到 WebUI 手动设置"
    fi
    ;;
  *)
    if grep -q '^cycle_fake=' $MODPATH/config/settings.conf; then
      sed -i "s/^cycle_fake=.*/cycle_fake=/" $MODPATH/config/settings.conf
    else
      _add_kv "cycle_fake="
    fi
    ui_print "  → 已选择：不伪装（保持真实循环显示）"
    ui_print "     安装后仍可在 WebUI「循环计数」里随时开启"
    ;;
esac
fi

# ---- 权限设置 ----
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/scripts 0 0 0755 0755
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755
set_perm $MODPATH/bin/freepps 0 0 0755
_vlog "文件部署完成"

ui_print " "
ui_print "========== 安装完成 =========="
ui_print " ▸ 重启后生效；入口：KernelSU 模块页 WebUI"
ui_print " ▸ 默认开启：电池解容 / 精确功率限流 / 云控屏蔽 / 公版PPS"
ui_print " ▸ 默认关闭：温控守护（需要就开，高温兜底自动处理）"
ui_print " ▸ 充电档位：全速 / 40W / 25W / 10W（WebUI 可调）"
ui_print " ▸ 详细说明与常见问题：见作者发布的 README_使用说明"
ui_print " ⚠ DTBO 是本模块唯一需要重启才生效的改动；OTA 会还原它，"
ui_print "   之后在 WebUI「DTBO」页点检查一致性，提示不一致就重刷一次。"
ui_print " 反馈：酷安@听夜风1337 / QQ 2835981842 / 群 1075975836"
ui_print " "
